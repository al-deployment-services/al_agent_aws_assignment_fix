"""
   Shared Library for AlertLogic Stuff
"""
